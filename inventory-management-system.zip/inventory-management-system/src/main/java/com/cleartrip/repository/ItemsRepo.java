package com.cleartrip.repository;

import com.cleartrip.entity.Items;

public interface ItemsRepo extends GenericRepo<Items>  {
	
}
